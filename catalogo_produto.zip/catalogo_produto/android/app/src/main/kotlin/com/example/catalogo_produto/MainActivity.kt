package com.example.catalogo_produto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
