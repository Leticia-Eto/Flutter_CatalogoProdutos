import 'package:flutter/material.dart';
import 'produto_widget.dart';

class EletronicoWidget extends ProdutoWidget {
  final String marca;
  final int garantiaMeses;

  const EletronicoWidget({
    Key? key,
    required String nome,
    required double preco,
    required String descricao,
    required String imagemUrl,
    required VoidCallback onTap,
    required this.marca,
    required this.garantiaMeses,
  }) : super(
          key: key,
          nome: nome,
          preco: preco,
          descricao: descricao,
          imagemUrl: imagemUrl,
          onTap: onTap,
        );

  @override
  String getTipoProduto() => 'Eletrônico';

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Card(
        margin: const EdgeInsets.all(10),
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(imagemUrl, height: 200, fit: BoxFit.cover, errorBuilder: (context, error, stackTrace) {
                return const SizedBox(
                  height: 200,
                  child: Center(child: Text('Erro ao carregar imagem')),
                );
              }),
              const SizedBox(height: 10),
              Text(nome, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text(descricao),
              const SizedBox(height: 5),
              Text('Preço: R\$ ${preco.toStringAsFixed(2)}'),
              Text('Marca: $marca'),
              Text('Garantia: $garantiaMeses meses'),
              Text('Tipo: ${getTipoProduto()}'),
            ],
          ),
        ),
      ),
    );
  }
}
