import 'package:flutter/material.dart';

abstract class ProdutoWidget extends StatelessWidget{ 
  // herda de Stateless
  // Essas são as varíaveis sendo 'construídas' e requeridas (obrigatório por o valor) no 'main.dart'
  final String nome;
  final double preco;
  final String descricao;
  final String imagemUrl;
  final VoidCallback onTap;
  const ProdutoWidget({
    Key? key,
    required this.nome,
    required this.preco,
    required this.descricao,
    required this.imagemUrl,
    required this.onTap,
  }) : super(key: key);

  //função para pegar o Tipo do Produto nas outras páginas, como o 'roupas_widget.dart

  String getTipoProduto();


}
