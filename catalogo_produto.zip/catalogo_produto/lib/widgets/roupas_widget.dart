import 'package:flutter/material.dart';
import 'produto_widget.dart';

class RoupasWidget extends ProdutoWidget {  
  // essa classe extende as propridade de ProdutoWidget 
  final String marca;//Essas são as varíaveis que não estão presentes no ProdutoWidget , mas em RoupasWidget
  final String cor;

  const RoupasWidget({ //Esse é o construtor da classe 
    Key? key,
    // Essas são as varíaveis sendo 'construídas' e requeridas (obrigatório por o valor) no 'main.dart'
    required String nome, 
    required double preco,
    required String descricao,
    required String imagemUrl,
    required VoidCallback onTap,
    required this.marca,
    required this.cor,
  }) : super(
          key: key,
          nome: nome,
          preco: preco,
          descricao: descricao,
          imagemUrl: imagemUrl,
          onTap: onTap,
        );

  @override
  String getTipoProduto() => 'Roupas'; //Essa é a função que vai pegar o tipo do produto para colocar no texto .Precisa ter o '@override',pois o código está sendo sobreescrito 
  // sobre a função existe no 'ProdutoWidget'

  @override
  // InkWell torna clicavel 
  //Dentro de 'Card' há as definições do design do Card , como a margin.
  // Column : mostra que a estrutura é feita na vertical , em colunas
  //errorBuilder: propriedade para lidar com erros de carregamento da imagem
  //Os 'Text' mostra o que vai aparecer no texto dentro do card, como 'Text('Cor: $cor '),' que mostra a Cor e o que esta na variável cor 
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Card(
        margin: const EdgeInsets.all(10),
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(imagemUrl, height: 200, fit: BoxFit.cover, errorBuilder: (context, error, stackTrace) {
                return const SizedBox(
                  height: 200,
                  child: Center(child: Text('Erro ao carregar imagem')),
                );
              }),
              const SizedBox(height: 10),
              Text(nome, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text(descricao),
              const SizedBox(height: 5),
              Text('Preço: R\$ ${preco.toStringAsFixed(2)}'),
              Text('Marca: $marca'),
              Text('Cor: $cor '),
              Text('Tipo: ${getTipoProduto()}'),
            ],
          ),
        ),
      ),
    );
  }
}
