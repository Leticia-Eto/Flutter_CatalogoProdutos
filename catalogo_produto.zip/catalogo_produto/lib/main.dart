// Os imports são necessários para que a chamada seja correta 

import 'package:flutter/material.dart';
import 'widgets/alimentos_widget.dart';
import 'widgets/produto_widget.dart';
import 'widgets/roupas_widget.dart';
import 'widgets/eletronicos_widget.dart';


void main() {
  runApp(const CatalogoProduto()); // roda o app
}

class CatalogoProduto extends StatelessWidget {
  //O CatalogoProduto contrói o 'Metrial bar'
  const CatalogoProduto({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catálogo de Produtos',
      theme: ThemeData(
        primaryColor: Colors.pink,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);


  void _onProdutoTap(BuildContext context, String nome) {
    //Essa função mostra os textos que vão aparecer quando o Card for clicado
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Produto selecionado'),
        content: Text('Você selecionou o produto: $nome'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  @override // necessário para demonstrar que estou sobrescrevendo um método da StatelessWidget
  Widget build(BuildContext context) {
    // Essa é a lista de produtos e seu conteúdo que irão aparecer em seus devidos Cards
    final List<ProdutoWidget> produtos = [
      EletronicoWidget(
        nome: 'iPhone',
        preco: 100.98,
        descricao: 'Celular da Apple',
        imagemUrl: 'https://cdn.awsli.com.br/300x300/1861/1861669/produto/239401024/iphone-15-apple-128gb--tela-de-6-1--c-mera-dupla-de-48mp-rosa--2--mx8rxednut.jpg',
        onTap: () => _onProdutoTap(context, 'iPhone'),
        marca: 'Apple',
        garantiaMeses: 12,
      ),
      AlimentosWidget(
        nome: 'Suchi',
        preco: 200.99,
        descricao: 'Comida Japonesa',
        imagemUrl: 'https://st.depositphotos.com/1588534/4135/i/450/depositphotos_41352091-stock-photo-maki-and-nigiri-sushi.jpg',
        onTap: () => _onProdutoTap(context, 'Suchi'),
        calorias: 20,
        dataValidade: '2025-09-09',
      ),

      RoupasWidget(
        nome: 'Vestido',
        preco: 200.99,
        descricao: 'Roupa chique',
        imagemUrl: 'https://images.tcdn.com.br/img/img_prod/886992/vestido_longo_de_festa_madrinhas_micro_tule_com_brilho_um_ombro_heresa_azul_marinho_4452_1_38e9794a909db522c1bd4394a487f6ee.jpg',
        onTap: () => _onProdutoTap(context, 'Vestido Azul da Renner'),
        marca: 'Renner',
        cor: 'Azul',
      ),


      
    ];
    //

    return Scaffold(
      //Esse bloco de códigos serve para criar a estrutura visual de uma tela de "Catálogo de Produtos" .
      appBar: AppBar(
        title: const Text('Catálogo de Produtos'),
        backgroundColor: Colors.pink,
      ),
      body: ListView.builder(
        itemCount: produtos.length,
        itemBuilder: (context, index) {
          return produtos[index];
        },
      ),
    );
  }
}
